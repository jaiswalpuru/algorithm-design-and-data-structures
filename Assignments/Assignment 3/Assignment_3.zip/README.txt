implement the quicksort algorithm as discussed in the class.
Sort a list of 15 numbers in asscneding order.
Repeat for descending order.
Submit the code
submit screen shot of each of the above two executions

Run : 
$ g++ -std=c++11 quick_sort.cc -o quicksort
$ ./quicksort
