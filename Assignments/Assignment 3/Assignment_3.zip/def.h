//contains all the definitions

#define SIZE 15
typedef std::vector<int>vi;
