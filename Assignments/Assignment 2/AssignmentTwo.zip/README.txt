Write a program to implement a delete operation from BST.
You will have to write the program to insert nodes in the BST also (we already did the algorithm in detail in the class for insert).
Insert the following nodes in the order mentioned here.
40, 60, 20, 80, 50, 10, 30, 15, 5, 35, 25, 45, 55, 70, 90, 32, 33, 48, 46
Do an inorder traversal.  
make screen shot
Now delete 40 (you decide predecessor or successor).
Do inorder traversal again.
Make screen shot
Now delete 20
Do inroder traversal
make screen shot.
Submit the code.
Submit the screen shots.

Run Code :
$ javac Main.java
$ java Main