class Node {
public:
    int val;
    int weight;
    Node(int val, int weight) : val(val),weight(weight) {}
    ~Node() {}
};
