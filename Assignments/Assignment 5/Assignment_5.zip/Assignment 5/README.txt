Implement Dijkstra's algorithm.
Your graph must have at least 10 vertices and 20 edges.
Print out the graph - list of vertices and edges(pair of vertices)
Run dijkstra's algorithm.
Print the tree that results - list of vertices in the tree (same as above) and list of edges that make up the tree.
You may use heap library. That is the only library you an use.
Submit the code and screen shots of execution results

Run :
1. $ g++ --std=c++11 dijkstra.cc -o dijkstra
2. $ ./dijkstra
