#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>

#define SIZE 31
#define LOAD_FACTOR 0.5

typedef std::vector<std::string> vs;
typedef std::hash<std::string> hs;
