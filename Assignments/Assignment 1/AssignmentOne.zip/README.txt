1. Make a single linked list of integers.  There should be at least 15 nodes,. The list should not be sorted.
Traverse the list.
Now sort the list using Bubble sort.  /do not use any other sorting algorithm. The list should be sorted such that your program unlinks the nodes and relinks them so that they are sorted. (DO NOT SWAP THE VALUES IN THE NODES).
use Bubble sort.
Traverse the list again.

Run using the below commands : 
$ javac Main.java
$ java Main

2. We covered binary search algorithm for an array.  Write program similar to binary search, but now divide the list into 3 parts each time.  So this would be tertiary search algorithm. 
Your program must be recursive,  
run it 2 times .. once try to search a number in the list.
Second time search a number not in the list.
Submit the code and screen shot of executions.

Run using the below commands :
$ javac Main.java
$ java Main
