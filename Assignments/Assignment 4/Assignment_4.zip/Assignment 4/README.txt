a. Write a program to do DFS topological sort . your program must be able to catch the loop.
Run the program on the attached graphs.
b. Write a program to do BFS topological sort . your program must be able to catch the loop.
Run the program on the attached graphs.
submit screen shots of execution results.
submit the code

Run :
$ g++ -std=c++11 topo.cc -o topo
$ ./topo
